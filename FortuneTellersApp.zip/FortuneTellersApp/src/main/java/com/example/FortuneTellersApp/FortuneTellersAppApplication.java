package com.example.FortuneTellersApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FortuneTellersAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FortuneTellersAppApplication.class, args);
	}

}

